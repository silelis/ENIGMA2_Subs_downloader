WHDD requires Smarttool and Smartctl.
Works when terminal is on full window.